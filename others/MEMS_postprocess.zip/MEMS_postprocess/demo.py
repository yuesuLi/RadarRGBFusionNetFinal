import pandas as pd
import numpy as np

data = pd.read_csv('./runs/novatel-utm.csv')

data['v'] = np.sqrt(data['vn(m/s)'].values * data['vn(m/s)'].values + data['ve(m/3)'].values * data['ve(m/3)'].values)
data['yaw/degree'] = data['yaw(rad)'].values / np.pi * 180

print(data[['v', 'yaw/degree']].describe())

print('done')