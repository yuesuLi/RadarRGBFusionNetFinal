# for ourDataset v1.0
import os
import glob
import time
import numpy as np
import pandas as pd

class MEMSDecoder(object):
    def __init__(self, asc_folder):
        asc_path = glob.glob(os.path.join(asc_folder, '*.ASC'))[0]
        self.asc_path = asc_path

        t1 = time.time()
        print('read logs...')
        self.logs = pd.read_csv(self.asc_path, sep=' ', header=None, names=['msg'])
        temp1 = self.logs['msg'].str.split(';', expand=True)
        temp1.columns = ['header', 'others']
        header = temp1['header'].str.split(',', expand=True)
        temp2 = temp1['others'].str.split('*', expand=True)
        temp2.columns = ['data', 'other']
        data = temp2['data'].str.split(',', expand=True)
        t2 = time.time()
        print('read logs use time: {:.3f}'.format(t2 - t1))

        mask_ins = '#INSPVAXA' == header.iloc[:, 0]
        mask_imu = ~mask_ins
        self.logs['msg_type'] = (mask_ins*0+mask_imu*1).astype('int8')

        # INSPVAXA: header 5-weeks 6-seconds
        # RAWIMUSA: data 0-weeks 1-seconds
        week = pd.concat([
            header[mask_ins].iloc[:, 5],
            data[mask_imu].iloc[:, 0]
        ])
        week.sort_index(inplace=True)
        self.logs['week'] = week.astype('int32')
        seconds = pd.concat([
            header[mask_ins].iloc[:, 6],
            data[mask_imu].iloc[:, 1]
        ])
        seconds.sort_index(inplace=True)
        self.logs['seconds'] = seconds.astype('float')

        self.logs['timestamp_gps'] = self.logs['week'] * 7 * 24 * 3600 + self.logs['seconds']
        self.logs['timestamp_unix'] = self.logs['timestamp_gps'] + 315964800 - 18

    def get_msg_ins(self, timestamp_unix_interest):
        assert isinstance(timestamp_unix_interest, str) or isinstance(timestamp_unix_interest, float) or isinstance(timestamp_unix_interest, int)
        timestamp_unix_interest = float(timestamp_unix_interest)
        offset = timestamp_unix_interest - self.logs[self.logs['msg_type'] == 0]['timestamp_unix']
        idx = offset.index[offset.abs().argmin()]
        msg = self.logs['msg'].iloc[idx]
        return MsgIns(msg)

    def get_msg_imu(self, timestamp_unix_interest):
        assert isinstance(timestamp_unix_interest, str) or isinstance(timestamp_unix_interest, float) or isinstance(timestamp_unix_interest, int)
        timestamp_unix_interest = float(timestamp_unix_interest)
        offset = timestamp_unix_interest - self.logs[self.logs['msg_type'] == 1]['timestamp_unix']
        idx = offset.index[offset.abs().argmin()]
        msg = self.logs['msg'].iloc[idx]
        return MsgImu(msg)

class MsgIns(object):
    def __init__(self, msg):
        feilds = msg.split(';')[-1].split('*')[0].split(',')
        self.ins_status = feilds[0]
        self.pos_type = feilds[1]
        self.lat = float(feilds[2])  # degrees
        self.long = float(feilds[3])  # degrees
        self.height = float(feilds[4])  # m
        self.undulation = float(feilds[5])  # m
        self.north_vel = float(feilds[6])  # m/s
        self.east_vel = float(feilds[7])  # m/s
        self.up_vel = float(feilds[8])  # m/s
        self.roll = float(feilds[9])  # degrees
        self.pitch = float(feilds[10])  # degrees
        self.azimuth = float(feilds[11])  # degrees

        # standard deviation
        self.lat_dev = float(feilds[12])  # degrees
        self.long_dev = float(feilds[13])  # degrees
        self.height_dev = float(feilds[14])  # m
        self.north_vel_dev = float(feilds[15])  # m/s
        self.east_vel_dev = float(feilds[16])  # m/s
        self.up_vel_dev = float(feilds[17])  # m/s
        self.roll_dev = float(feilds[18])  # degrees
        self.pitch_dev = float(feilds[19])  # degrees
        self.azimuth_dev = float(feilds[20])  # degrees

class MsgImu(object):
    def __init__(self, msg):
        feilds = msg.split(';')[-1].split('*')[0].split(',')

        self.week = int(feilds[0])
        self.seconds_into_week = float(feilds[1])
        self.imu_status = feilds[2]

        accel_scale_factor = (0.400 / 65536) / 200  # mG/s/LSB
        self.z_accel_output = float(feilds[3]) * accel_scale_factor
        self.y_accel_output = -float(feilds[4]) * accel_scale_factor
        self.x_accel_output = float(feilds[5]) * accel_scale_factor

        gyro_scale_factor = (0.0151515 / 65536) / 200  # deg/LSB
        self.z_gyro_output = float(feilds[6]) * gyro_scale_factor
        self.y_gyro_output = -float(feilds[7]) * gyro_scale_factor
        self.x_gyro_output = float(feilds[8]) * gyro_scale_factor

class MEMSGenerator(object):
    def __init__(self, asc_folder, output_path=None):
        asc_path = glob.glob(os.path.join(asc_folder, '*.ASC'))[0]
        self.asc_path = asc_path
        if output_path is None:
            default_folder = './runs'
            if not os.path.exists(default_folder):
                os.mkdir(default_folder)
                print('create {}'.format(default_folder))

            self.output_path = os.path.join(default_folder, os.path.basename(asc_path).split('.')[0]+'.csv')
        else:
            self.output_path = output_path

        if os.path.exists(self.output_path):
            print('read from {}'.format(self.output_path))
            self.data = pd.read_csv(self.output_path)
        else:
            print('read from {}'.format(self.asc_path))
            self.data = self.get_data()
            print('save to {}'.format(self.output_path))
            self.data.to_csv(self.output_path, index=False)

    def get_data(self):
        logs = pd.read_csv(self.asc_path, sep=' ', header=None, names=['msg'])
        print('all_msg length = {}'.format(len(logs)))
        logs = logs[logs.iloc[:, 0].str.contains('#INSPVAXA')]
        print('ins_msg length = {}'.format(len(logs)))
        logs = logs['msg'].str.split(r'[,;*]', expand=True)

        data = pd.DataFrame({
            'ins_status': logs.iloc[:, 10],
            'week': logs.iloc[:, 5].astype('int32'),
            'second': logs.iloc[:, 6].astype('float32'),
            'latitude': logs.iloc[:, 12].astype('float32'),
            'longitude': logs.iloc[:, 13].astype('float32'),
            'height': logs.iloc[:, 14].astype('float32'),
            'north_vel': logs.iloc[:, 16].astype('float32'),
            'east_vel': logs.iloc[:, 17].astype('float32'),
            'up_vel': logs.iloc[:, 18].astype('float32'),
            'roll': logs.iloc[:, 19].astype('float32'),
            'pitch': logs.iloc[:, 20].astype('float32'),
            'yaw': logs.iloc[:, 21].astype('float32')
        })
        data = data[data['ins_status'].str.contains('INS_SOLUTION_GOOD')]
        print('valid length = {}'.format(len(data)))
        # data['timestamp_gps'] = data['week'] * 7 * 24 * 3600 + data['second']
        # data['timestamp_unix'] = data['timestamp_gps'] + 315964800 - 18
        return data


def main1():
    asc_folder = 'F:\\GNSS\\MEMS\\20211025_1'

    md = MEMSDecoder(asc_folder)

    timestamp_unix_interest = '1635145120.915'
    msg_ins = md.get_msg_ins(timestamp_unix_interest)
    msg_imu = md.get_msg_imu(timestamp_unix_interest)

    print('done')

def main2():
    asc_folder = 'F:\\GNSS\\MEMS\\20211025_1'

    mg = MEMSGenerator(asc_folder)

    print('done')


if __name__ == '__main__':
    main2()

