import os
import time
import pandas as pd
import numpy as np

from mems_v1 import MEMSGenerator

output_path = os.path.join('./runs', 'heading_imu_input.csv')
asc_folder = 'F:\\GNSS\\MEMS\\20211025_1'
mg = MEMSGenerator(asc_folder)

idx_start = 45000
idx_end = 50000

timestamp_gps = mg.data['week'].iloc[idx_start:idx_end] * 7 * 24 * 3600 + mg.data['second'].iloc[idx_start:idx_end]
timestamp_unix = timestamp_gps + 315964800 - 18
gps_time = [
    time.strftime('%Y-%m-%d-%H-%M-%S', time.gmtime(timestamp_unix.iloc[i])) + '-{:>03d}'.format(round(timestamp_unix.iloc[i]%1*1000))
    for i in range(len(timestamp_unix))
]

lat = mg.data['latitude'].iloc[idx_start:idx_end].values
lon = mg.data['longitude'].iloc[idx_start:idx_end].values
h = mg.data['height'].iloc[idx_start:idx_end].values
# WGS84长半轴
a = 6378137
# WGS84椭球扁率
f = 1 / 298.257223563
# WGS84短半轴
b = a * (1 - f)
# WGS84椭球第一偏心率
e = np.sqrt(a * a - b * b) / a
# WGS84椭球面卯酉圈的曲率半径
N = a / np.sqrt(1 - e * e * np.sin(lat * np.pi / 180) * np.sin(lat * np.pi / 180))
x = (N + h) * np.cos(lat * np.pi / 180) * np.cos(lon * np.pi / 180)
y = (N + h) * np.cos(lat * np.pi / 180) * np.sin(lon * np.pi / 180)
z = (N * (1 - (e * e)) + h) * np.sin(lat * np.pi / 180)

vn = mg.data['north_vel'].iloc[idx_start:idx_end]
ve = mg.data['east_vel'].iloc[idx_start:idx_end]
vu = mg.data['up_vel'].iloc[idx_start:idx_end]

roll = mg.data['roll'].iloc[idx_start:idx_end] / 180 * np.pi
pitch = mg.data['pitch'].iloc[idx_start:idx_end] / 180 * np.pi
yaw = mg.data['yaw'].iloc[idx_start:idx_end] / 180 * np.pi

input_data = pd.DataFrame({
    'gps_time': gps_time,
    'x': x,
    'y': y,
    'z': z,
    've(m/s)': ve,
    'vn(m/s)': vn,
    'vu(m/s)': vu,
    'roll(rad)': roll,
    'pitch(rad)': pitch,
    'yaw(rad)': yaw
})

input_data.to_csv(output_path, sep=',', index=False, header=True)

check = input_data.copy()
check['v'] = np.sqrt(vn.values * vn.values + ve.values * ve.values)
check['yaw/degree'] = mg.data['yaw'].iloc[idx_start:idx_end].values

print('done')