import time
import gmplot
import numpy as np

from mems_v1 import MEMSGenerator

asc_folder = 'F:\\GNSS\\MEMS\\20211025_1'
mg = MEMSGenerator(asc_folder)

data = mg.data
# WGS84坐标 转 GCJ02坐标火星坐标
in_china = np.logical_and(
  np.logical_and(data['latitude'].values > 3.86, data['latitude'].values < 53.55),
  np.logical_and(data['longitude'].values > 73.66, data['longitude'].values < 135.05)
)
lng = data['longitude'].values
lat = data['latitude'].values
lng_r = data['longitude'].values - 105.0
lat_r = data['latitude'].values - 35.0
dlng = 300.0 + lng_r + 2.0 * lat_r + 0.1 * lng_r * lng_r + 0.1 * lng_r * lat_r + 0.1 * np.sqrt(np.fabs(lng_r)) + \
       (20.0 * np.sin(6.0 * lng_r * np.pi) + 20.0 * np.sin(2.0 * lng_r * np.pi)) * 2.0 / 3.0 + \
       (20.0 * np.sin(lng_r * np.pi) + 40.0 * np.sin(lng_r / 3.0 * np.pi)) * 2.0 / 3.0 + \
       (150.0 * np.sin(lng_r / 12.0 * np.pi) + 300.0 * np.sin(lng_r / 30.0 * np.pi)) * 2.0 / 3.0
dlat = -100.0 + 2.0 * lng_r + 3.0 * lat_r + 0.2 * lat_r * lat_r +  0.1 * lng_r * lat_r + 0.2 * np.sqrt(np.fabs(lng_r)) + \
       (20.0 * np.sin(6.0 * lng_r * np.pi) + 20.0 * np.sin(2.0 * lng_r * np.pi)) * 2.0 / 3.0 + \
       (20.0 * np.sin(lat_r * np.pi) + 40.0 * np.sin(lat_r / 3.0 * np.pi)) * 2.0 / 3.0 + \
       (160.0 * np.sin(lat_r / 12.0 * np.pi) + 320 * np.sin(lat_r * np.pi / 30.0)) * 2.0 / 3.0
radlat = lat / 180.0 * np.pi
magic = np.sin(radlat)
# 地球的角离心率
ee = 0.00669342162296594323
magic = 1 - ee * magic * magic
sqrtmagic = np.sqrt(magic)
# 长半轴长度
a = 6378245.0
dlat = (dlat * 180.0) / ((a * (1 - ee)) / (magic * sqrtmagic) * np.pi)
dlng = (dlng * 180.0) / (a / sqrtmagic * np.cos(radlat) * np.pi)
gclng = lng + dlng
gclat = lat + dlat

data['gclat'] = gclat * in_china + lat * np.logical_not(in_china)
data['gclng'] = gclng * in_china + lng * np.logical_not(in_china)

# interest
# idx_start = 0
# idx_end = 44000

idx_start = 45000
idx_end = 50000

# Create the map plotter:
apikey = 'AIzaSyB1wHYleT18jOipAGKcUAiMewG2zrh8f8c' # (your API key here)
gmap = gmplot.GoogleMapPlotter(mg.data['gclat'].iloc[idx_start], mg.data['gclng'].iloc[idx_start], 14, apikey=apikey)

gmap.marker(mg.data['gclat'].iloc[idx_start], mg.data['gclng'].iloc[idx_start], label='Start', color='green')
gmap.marker(mg.data['gclat'].iloc[idx_end], mg.data['gclng'].iloc[idx_end], label='End', color='green')

path = zip(*[(mg.data['gclat'].iloc[i], mg.data['gclng'].iloc[i]) for i in np.arange(idx_start, idx_end)])
gmap.plot(*path, edge_width=4, color='red')


start_timestamp_gps = data['week'].iloc[idx_start] * 7 * 24 * 3600 + data['second'].iloc[idx_start]
start_timestamp_unix = start_timestamp_gps + 315964800 - 18
# utc time
toh_utc_time_str = time.strftime(
    '%Y-%m-%d %H:%M:%S', time.gmtime(start_timestamp_unix)
)
# local time
toh_local_time_str = time.strftime(
    '%Y-%m-%d %H:%M:%S', time.localtime(start_timestamp_unix)
)
print(
  'START: timestamp_gps={:.6f}, timestamp_unix={:.6f}, utc_time: {}, local_time: {}'.format(
    start_timestamp_gps, start_timestamp_unix, toh_utc_time_str, toh_local_time_str
  )
)


end_timestamp_gps = data['week'].iloc[idx_end] * 7 * 24 * 3600 + data['second'].iloc[idx_end]
end_timestamp_unix = end_timestamp_gps + 315964800 - 18
# utc time
toh_utc_time_str = time.strftime(
    '%Y-%m-%d %H:%M:%S', time.gmtime(end_timestamp_unix)
)
# local time
toh_local_time_str = time.strftime(
    '%Y-%m-%d %H:%M:%S', time.localtime(end_timestamp_unix)
)
print(
  '  END: timestamp_gps={:.6f}, timestamp_unix={:.6f}, utc_time: {}, local_time: {}'.format(
    end_timestamp_gps, end_timestamp_unix, toh_utc_time_str, toh_local_time_str
  )
)


# Draw the map to an HTML file:
gmap.draw('./runs/driving8.html')